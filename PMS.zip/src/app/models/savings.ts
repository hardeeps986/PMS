export interface Savings {
    savingsGoal?:number;
    currentSavings?:number;
    annualInterest?:number;
    compounding?:string;
    numberOfYears?:number;
    monthlyInvestment?:number;
}
